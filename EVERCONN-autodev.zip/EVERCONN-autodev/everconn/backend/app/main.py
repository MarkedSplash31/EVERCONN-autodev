# AUTODEV_STUB — everconn backend entrypoint
# This file will be populated by the autodev agent

from fastapi import FastAPI

app = FastAPI(title="EVERCONN Backend", version="0.1.0")


@app.get("/health")
async def health():
    return {"status": "ok"}
