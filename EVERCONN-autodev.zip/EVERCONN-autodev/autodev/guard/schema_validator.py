"""Validate JSON artifacts against their JSON Schema definitions."""

from __future__ import annotations

import json
from pathlib import Path

import jsonschema
import structlog

from autodev.core.constants import SCHEMA_FILES

log = structlog.get_logger(__name__)


class SchemaValidator:
    """Validates JSON files against schemas in the schema directory."""

    def __init__(self, schema_dir: Path) -> None:
        self.schema_dir = Path(schema_dir)
        self._cache: dict[str, dict] = {}

    def _load_schema(self, schema_name: str) -> dict | None:
        if schema_name in self._cache:
            return self._cache[schema_name]

        filename = SCHEMA_FILES.get(schema_name)
        if not filename:
            log.warning("schema_validator.unknown_schema", name=schema_name)
            return None

        path = self.schema_dir / filename
        if not path.exists():
            log.warning("schema_validator.schema_not_found", path=str(path))
            return None

        schema = json.loads(path.read_text(encoding="utf-8"))
        self._cache[schema_name] = schema
        return schema

    def validate_file(self, file_path: Path, schema_name: str) -> list[str]:
        """Returns a list of error messages (empty = valid)."""
        schema = self._load_schema(schema_name)
        if schema is None:
            return [f"Schema '{schema_name}' not available"]

        try:
            data = json.loads(file_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            return [f"Cannot read artifact: {exc}"]

        return self.validate_data(data, schema_name, schema)

    def validate_data(self, data: dict, schema_name: str, schema: dict | None = None) -> list[str]:
        if schema is None:
            schema = self._load_schema(schema_name)
        if schema is None:
            return [f"Schema '{schema_name}' not available"]

        validator = jsonschema.Draft7Validator(schema)
        errors = sorted(validator.iter_errors(data), key=lambda e: list(e.path))
        return [f"{'.'.join(str(p) for p in err.path) or 'root'}: {err.message}" for err in errors]
