"""Load and parse the guard policy YAML."""

from __future__ import annotations

from pathlib import Path

import structlog
import yaml

log = structlog.get_logger(__name__)


class PolicyLoader:
    """Reads policy.yaml and returns a parsed dict."""

    def __init__(self, policy_path: Path) -> None:
        self.policy_path = Path(policy_path)

    def load(self) -> dict:
        if not self.policy_path.exists():
            log.warning("policy_loader.not_found", path=str(self.policy_path))
            return self._default_policy()

        with self.policy_path.open(encoding="utf-8") as f:
            policy = yaml.safe_load(f)

        log.info("policy_loader.loaded", path=str(self.policy_path))
        return policy or self._default_policy()

    @staticmethod
    def _default_policy() -> dict:
        return {
            "version": "1.0",
            "severity_map": {
                "missing_meta": "critical",
                "missing_manifest": "critical",
                "missing_status": "critical",
                "missing_verification": "critical",
                "schema_meta": "error",
                "schema_manifest": "error",
                "schema_status": "error",
                "schema_verification": "critical",
                "verifier_name_mismatch": "critical",
            },
            "blocking_severities": ["critical", "error"],
        }
