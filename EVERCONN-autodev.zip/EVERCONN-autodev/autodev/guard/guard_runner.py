"""Runtime guard — orchestrates policy loading, schema validation, and artifact writing."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import structlog

from autodev.core.config import get_settings
from autodev.core.constants import VERIFIER_NAME
from autodev.core.exceptions import GuardError
from autodev.guard.artifact_writer import ArtifactWriter
from autodev.guard.hash_engine import HashEngine
from autodev.guard.manifest_builder import ManifestBuilder
from autodev.guard.policy_loader import PolicyLoader
from autodev.guard.schema_validator import SchemaValidator
from autodev.guard.severity_resolver import SeverityResolver

log = structlog.get_logger(__name__)


@dataclass
class GuardViolation:
    rule: str
    severity: str
    message: str
    artifact: str | None = None


@dataclass
class GuardReport:
    job_id: str
    passed: bool
    violations: list[GuardViolation] = field(default_factory=list)
    artifact_path: Path | None = None
    verification_hash: str = ""


class GuardRunner:
    """Orchestrates the full guard pipeline for a job."""

    def __init__(self, job_id: str) -> None:
        self.job_id = job_id
        self.settings = get_settings()
        self.policy = PolicyLoader(self.settings.guard_policy_path).load()
        self.validator = SchemaValidator(self.settings.guard_schema_dir)
        self.severity = SeverityResolver(self.policy)
        self.hash_engine = HashEngine()
        self.manifest_builder = ManifestBuilder(job_id=job_id)
        self.writer = ArtifactWriter(
            job_id=job_id,
            artifacts_dir=self.settings.artifacts_dir,
        )

    def run(self, job_dir: Path) -> GuardReport:
        log.info("guard.run.start", job_id=self.job_id)
        violations: list[GuardViolation] = []

        # 1. Validate all schema artifacts
        for schema_name in ["meta", "manifest", "status", "verification"]:
            artifact_file = job_dir / f"{schema_name}.json"
            if not artifact_file.exists():
                if self.severity.is_blocking(f"missing_{schema_name}"):
                    violations.append(
                        GuardViolation(
                            rule=f"missing_{schema_name}",
                            severity="critical",
                            message=f"Required artifact missing: {artifact_file.name}",
                        )
                    )
                continue
            errors = self.validator.validate_file(artifact_file, schema_name)
            for err in errors:
                sev = self.severity.resolve(f"schema_{schema_name}")
                violations.append(
                    GuardViolation(rule=f"schema_{schema_name}", severity=sev, message=err)
                )

        # 2. Check verifier name in verification.json
        verification_file = job_dir / "verification.json"
        if verification_file.exists():
            import json
            data = json.loads(verification_file.read_text(encoding="utf-8"))
            actual_name = data.get("verifier", {}).get("name", "")
            if actual_name != VERIFIER_NAME:
                violations.append(
                    GuardViolation(
                        rule="verifier_name_mismatch",
                        severity="critical",
                        message=f"verifier.name must be {VERIFIER_NAME!r}, got {actual_name!r}",
                    )
                )

        # 3. Build manifest
        manifest = self.manifest_builder.build(job_dir)

        # 4. Compute verification hash
        v_hash = self.hash_engine.hash_manifest(manifest)

        blocking = [v for v in violations if v.severity in ("critical", "error")]
        passed = len(blocking) == 0

        report = GuardReport(
            job_id=self.job_id,
            passed=passed,
            violations=violations,
            verification_hash=v_hash,
        )

        # 5. Write artifact only on PASS
        if passed:
            artifact_path = self.writer.write(job_dir, manifest, v_hash)
            report.artifact_path = artifact_path
            log.info("guard.run.pass", job_id=self.job_id, artifact=str(artifact_path))
        else:
            log.warning("guard.run.fail", job_id=self.job_id, violations=len(blocking))

        return report
