"""Build the guard manifest from job artifacts (scope: artifacts_only)."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

import structlog

from autodev.core.constants import ARTIFACT_MAP
from autodev.guard.hash_engine import HashEngine

log = structlog.get_logger(__name__)


class ManifestBuilder:
    """Constructs a manifest dict from the artifacts present in a job directory."""

    # Artifacts always expected (scope: artifacts_only)
    REQUIRED_ARTIFACTS = {"meta", "manifest", "status", "verification"}

    def __init__(self, job_id: str) -> None:
        self.job_id = job_id
        self.hash_engine = HashEngine()

    def build(self, job_dir: Path) -> dict:
        entries = {}
        for key, filename in ARTIFACT_MAP.items():
            file_path = job_dir / filename
            if not file_path.exists():
                continue
            entries[key] = {
                "filename": filename,
                "sha256": self.hash_engine.hash_file(file_path),
                "size_bytes": file_path.stat().st_size,
            }

        manifest = {
            "job_id": self.job_id,
            "built_at": datetime.now(UTC).isoformat(),
            "scope": "artifacts_only",
            "artifacts": entries,
        }
        log.info("manifest_builder.built", job_id=self.job_id, artifact_count=len(entries))
        return manifest
