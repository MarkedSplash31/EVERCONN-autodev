"""Stage: test — run pytest on job workspace."""

from __future__ import annotations

import asyncio
from pathlib import Path

from autodev.core.exceptions import DeployError


async def run(job_id: str, job_dir: Path, target: str) -> dict:
    proc = await asyncio.create_subprocess_shell(
        "pytest --tb=short -q",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=job_dir,
    )
    stdout, stderr = await proc.communicate()
    output = stdout.decode("utf-8", errors="replace")
    if proc.returncode != 0:
        raise DeployError("test", output + stderr.decode("utf-8", errors="replace"))
    return {"test": "pass", "output": output}
