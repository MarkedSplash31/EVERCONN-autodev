"""Stage: build — package artifacts (Docker image or dist archive)."""

from __future__ import annotations

from pathlib import Path

import structlog

from autodev.core.exceptions import DeployError

log = structlog.get_logger(__name__)


async def run(job_id: str, job_dir: Path, target: str) -> dict:
    log.info("stage_build.run", job_id=job_id, target=target)
    if target == "local_docker":
        return await _build_docker(job_id, job_dir)
    if target == "vercel":
        return {"build": "skipped", "reason": "Vercel builds in cloud"}
    return {"build": "skipped", "reason": f"No build step for target={target!r}"}


async def _build_docker(job_id: str, job_dir: Path) -> dict:
    import asyncio

    tag = f"autodev-{job_id[:8]}:latest"
    proc = await asyncio.create_subprocess_shell(
        f"docker build -t {tag} .",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=job_dir,
    )
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise DeployError("build", stderr.decode("utf-8", errors="replace"))
    return {"build": "pass", "image": tag}
