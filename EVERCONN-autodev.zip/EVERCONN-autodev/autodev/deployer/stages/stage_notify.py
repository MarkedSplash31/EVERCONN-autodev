"""Stage: notify — send deployment result notification."""

from __future__ import annotations

from pathlib import Path

import httpx
import structlog

from autodev.core.config import get_settings

log = structlog.get_logger(__name__)


async def run(job_id: str, job_dir: Path, target: str) -> dict:
    settings = get_settings()
    if not settings.slack_webhook_url:
        log.info("stage_notify.skip", reason="no slack webhook configured")
        return {"notify": "skipped"}

    payload = {
        "text": f":white_check_mark: *autodev* job `{job_id}` deployed to `{target}` successfully."
    }
    async with httpx.AsyncClient() as client:
        resp = await client.post(settings.slack_webhook_url, json=payload, timeout=10)
        resp.raise_for_status()

    log.info("stage_notify.sent", job_id=job_id)
    return {"notify": "sent"}
