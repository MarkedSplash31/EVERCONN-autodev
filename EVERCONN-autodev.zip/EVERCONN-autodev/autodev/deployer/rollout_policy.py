"""Rollout policy — controls canary percentages, rollback thresholds, etc."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class RolloutPolicy:
    strategy: str = "immediate"   # immediate | canary | blue_green
    canary_percent: int = 10
    max_error_rate: float = 0.05   # 5% — triggers auto-rollback
    rollback_on_failure: bool = True
    notify_on_success: bool = True
    notify_on_failure: bool = True

    @classmethod
    def from_dict(cls, data: dict) -> "RolloutPolicy":
        return cls(
            strategy=data.get("strategy", "immediate"),
            canary_percent=data.get("canary_percent", 10),
            max_error_rate=data.get("max_error_rate", 0.05),
            rollback_on_failure=data.get("rollback_on_failure", True),
            notify_on_success=data.get("notify_on_success", True),
            notify_on_failure=data.get("notify_on_failure", True),
        )

    def to_dict(self) -> dict:
        return {
            "strategy": self.strategy,
            "canary_percent": self.canary_percent,
            "max_error_rate": self.max_error_rate,
            "rollback_on_failure": self.rollback_on_failure,
            "notify_on_success": self.notify_on_success,
            "notify_on_failure": self.notify_on_failure,
        }
