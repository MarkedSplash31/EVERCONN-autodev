"""Deploy target: remote host via SSH."""

from __future__ import annotations

import asyncio
from pathlib import Path

import structlog

from autodev.core.config import get_settings
from autodev.core.exceptions import DeployError

log = structlog.get_logger(__name__)


async def push(job_id: str, job_dir: Path) -> dict:
    settings = get_settings()
    if not settings.ssh_deploy_host:
        raise DeployError("push", "SSH deploy host not configured (SSH_DEPLOY_HOST)")

    host = settings.ssh_deploy_host
    user = settings.ssh_deploy_user
    key = settings.ssh_deploy_key_path

    remote_dir = f"/opt/autodev/jobs/{job_id}"
    rsync_cmd = (
        f"rsync -az --delete -e 'ssh -i {key} -o StrictHostKeyChecking=no' "
        f"{job_dir}/ {user}@{host}:{remote_dir}/"
    )
    log.info("remote_ssh.rsync", host=host, remote_dir=remote_dir)

    proc = await asyncio.create_subprocess_shell(
        rsync_cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    _, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise DeployError("push", f"rsync failed: {stderr.decode('utf-8', errors='replace')}")

    log.info("remote_ssh.done", host=host)
    return {"target": "remote_ssh", "host": host, "remote_dir": remote_dir}
