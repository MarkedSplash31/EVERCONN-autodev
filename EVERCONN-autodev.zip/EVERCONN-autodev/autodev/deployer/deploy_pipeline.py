"""Multi-stage deployment pipeline orchestrator."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

import structlog

from autodev.core.exceptions import DeployError
from autodev.deployer.stages import (
    stage_build,
    stage_guard_verify,
    stage_lint,
    stage_notify,
    stage_push,
    stage_test,
)

log = structlog.get_logger(__name__)


class StageStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class StageResult:
    name: str
    status: StageStatus
    output: dict = field(default_factory=dict)
    error: str | None = None


@dataclass
class PipelineResult:
    job_id: str
    target: str
    stages: list[StageResult] = field(default_factory=list)

    @property
    def success(self) -> bool:
        return all(s.status in (StageStatus.PASSED, StageStatus.SKIPPED) for s in self.stages)


STAGE_ORDER = [
    ("lint", stage_lint),
    ("test", stage_test),
    ("build", stage_build),
    ("guard_verify", stage_guard_verify),   # BLOCKING
    ("push", stage_push),
    ("notify", stage_notify),
]


class DeployPipeline:
    """Runs deployment stages in order, stopping on any blocking failure."""

    def __init__(self, job_id: str, target: str, job_dir: Path) -> None:
        self.job_id = job_id
        self.target = target
        self.job_dir = job_dir

    async def run(self) -> PipelineResult:
        result = PipelineResult(job_id=self.job_id, target=self.target)
        log.info("pipeline.start", job_id=self.job_id, target=self.target)

        for stage_name, stage_module in STAGE_ORDER:
            log.info("pipeline.stage.start", stage=stage_name)
            try:
                output = await stage_module.run(job_id=self.job_id, job_dir=self.job_dir, target=self.target)
                result.stages.append(StageResult(name=stage_name, status=StageStatus.PASSED, output=output))
            except DeployError as exc:
                result.stages.append(StageResult(name=stage_name, status=StageStatus.FAILED, error=str(exc)))
                log.error("pipeline.stage.failed", stage=stage_name, error=str(exc))
                break  # halt on first failure

        log.info("pipeline.done", job_id=self.job_id, success=result.success)
        return result
