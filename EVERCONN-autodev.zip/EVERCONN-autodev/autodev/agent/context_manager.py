"""Manages per-job context: working memory, codebase state, conversation history."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import structlog

from autodev.core.config import get_settings

log = structlog.get_logger(__name__)


@dataclass
class JobContext:
    job_id: str
    description: str = ""
    working_dir: Path = field(default_factory=Path)
    conversation_history: list[dict] = field(default_factory=list)
    file_changes: list[str] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)


class ContextManager:
    """Holds and mutates the context for a single job execution."""

    def __init__(self, job_id: str) -> None:
        self.settings = get_settings()
        self.ctx = JobContext(
            job_id=job_id,
            working_dir=self.settings.runtime_dir / "jobs" / job_id,
        )

    def add_message(self, role: str, content: str) -> None:
        self.ctx.conversation_history.append({"role": role, "content": content})

    def record_file_change(self, path: str) -> None:
        if path not in self.ctx.file_changes:
            self.ctx.file_changes.append(path)

    def set_metadata(self, key: str, value) -> None:
        self.ctx.metadata[key] = value

    def get_history(self) -> list[dict]:
        return self.ctx.conversation_history.copy()

    @property
    def job_id(self) -> str:
        return self.ctx.job_id
