"""Skill: review code for quality, security, and style issues."""

from __future__ import annotations

import anthropic
import structlog

from autodev.agent.context_manager import ContextManager
from autodev.agent.task_planner import PlanStep
from autodev.core.config import get_settings

log = structlog.get_logger(__name__)


async def execute(step: PlanStep, context: ContextManager) -> dict:
    settings = get_settings()
    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)

    code = step.inputs.get("code", "")

    try:
        system_prompt = open("autodev/agent/prompts/code_review.txt").read()
    except FileNotFoundError:
        system_prompt = "You are a senior code reviewer. Return structured JSON with issues and suggestions."

    response = client.messages.create(
        model=settings.anthropic_model,
        max_tokens=2048,
        system=system_prompt,
        messages=[{"role": "user", "content": f"Review this code:\n```\n{code}\n```"}],
    )
    review = response.content[0].text
    log.info("code_reviewer.done")
    return {"review": review}
