"""Skill: analyze imports and resolve missing dependencies."""

from __future__ import annotations

import re

import structlog

from autodev.agent.context_manager import ContextManager
from autodev.agent.task_planner import PlanStep

log = structlog.get_logger(__name__)

STDLIB_MODULES = {
    "os", "sys", "re", "json", "pathlib", "typing", "dataclasses",
    "collections", "itertools", "functools", "abc", "io", "time",
    "datetime", "hashlib", "hmac", "uuid", "copy", "math", "random",
    "string", "textwrap", "struct", "enum", "contextlib", "asyncio",
    "concurrent", "threading", "subprocess", "shutil", "tempfile",
    "importlib", "inspect", "traceback", "warnings", "logging",
}


async def execute(step: PlanStep, context: ContextManager) -> dict:
    code = step.inputs.get("code", "")
    imports = _extract_imports(code)
    third_party = [imp for imp in imports if imp not in STDLIB_MODULES and not imp.startswith("autodev")]
    log.info("dependency_resolver.done", third_party=third_party)
    return {"imports": imports, "third_party": third_party}


def _extract_imports(code: str) -> list[str]:
    pattern = re.compile(r"^(?:import|from)\s+([\w.]+)", re.MULTILINE)
    return list({m.group(1).split(".")[0] for m in pattern.finditer(code)})
