"""Skill: infer JSON Schema from example data or Pydantic models."""

from __future__ import annotations

import json

import structlog

from autodev.agent.context_manager import ContextManager
from autodev.agent.task_planner import PlanStep

log = structlog.get_logger(__name__)


def _infer_type(value) -> dict:
    if isinstance(value, bool):
        return {"type": "boolean"}
    if isinstance(value, int):
        return {"type": "integer"}
    if isinstance(value, float):
        return {"type": "number"}
    if isinstance(value, str):
        return {"type": "string"}
    if isinstance(value, list):
        item_types = [_infer_type(v) for v in value[:3]]
        return {"type": "array", "items": item_types[0] if item_types else {}}
    if isinstance(value, dict):
        return {
            "type": "object",
            "properties": {k: _infer_type(v) for k, v in value.items()},
            "required": list(value.keys()),
        }
    return {}


async def execute(step: PlanStep, context: ContextManager) -> dict:
    sample_data = step.inputs.get("sample_data", {})
    if isinstance(sample_data, str):
        sample_data = json.loads(sample_data)

    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        **_infer_type(sample_data),
    }
    log.info("schema_inferrer.done")
    return {"schema": schema}
