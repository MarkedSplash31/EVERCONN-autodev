"""Skill: read, write, and list files within the sandbox working directory."""

from __future__ import annotations

from pathlib import Path

import structlog

from autodev.agent.context_manager import ContextManager
from autodev.agent.task_planner import PlanStep
from autodev.core.exceptions import SandboxError

log = structlog.get_logger(__name__)


async def execute(step: PlanStep, context: ContextManager) -> dict:
    op = step.inputs.get("op", "read")
    path = step.inputs.get("path", "")

    if not path:
        raise SandboxError("file_manager: 'path' input is required")

    target = (context.ctx.working_dir / path).resolve()

    if op == "read":
        if not target.exists():
            return {"content": None, "exists": False}
        return {"content": target.read_text(encoding="utf-8"), "exists": True}

    elif op == "write":
        content = step.inputs.get("content", "")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        context.record_file_change(str(target))
        log.info("file_manager.write", path=str(target))
        return {"written": str(target)}

    elif op == "list":
        if not target.is_dir():
            return {"files": []}
        return {"files": [str(p) for p in target.iterdir()]}

    raise SandboxError(f"file_manager: unknown op={op!r}")
