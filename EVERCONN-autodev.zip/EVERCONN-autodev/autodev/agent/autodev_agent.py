"""Main autonomous development agent."""

from __future__ import annotations

import structlog

from autodev.agent.context_manager import ContextManager
from autodev.agent.decision_engine import DecisionEngine
from autodev.agent.task_planner import TaskPlanner
from autodev.core.config import get_settings
from autodev.core.constants import JOB_STATES

log = structlog.get_logger(__name__)


class AutodevAgent:
    """Orchestrates task planning, decision making, and skill execution."""

    def __init__(self, job_id: str) -> None:
        self.job_id = job_id
        self.settings = get_settings()
        self.context = ContextManager(job_id=job_id)
        self.planner = TaskPlanner(context=self.context)
        self.engine = DecisionEngine(context=self.context)
        self._state: str = "RUNNING"

    @property
    def state(self) -> str:
        return self._state

    async def run(self, description: str) -> dict:
        """Execute the full agent loop for a job description."""
        log.info("agent.run.start", job_id=self.job_id, description=description[:80])
        try:
            plan = await self.planner.decompose(description)
            log.info("agent.plan.ready", job_id=self.job_id, steps=len(plan.steps))

            for step in plan.steps:
                result = await self.engine.execute_step(step)
                if result.abort:
                    self._state = "ABORTED"
                    return self._summary()

            self._state = "SUCCESS"
        except Exception as exc:
            log.error("agent.run.error", job_id=self.job_id, error=str(exc))
            self._state = "FAILED"

        return self._summary()

    def _summary(self) -> dict:
        return {"job_id": self.job_id, "state": self._state}
