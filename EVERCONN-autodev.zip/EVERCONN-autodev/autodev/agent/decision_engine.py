"""Decides which skill to invoke for a plan step and handles the result."""

from __future__ import annotations

from dataclasses import dataclass

import structlog

from autodev.agent.context_manager import ContextManager
from autodev.agent.task_planner import PlanStep

log = structlog.get_logger(__name__)

SKILL_REGISTRY: dict[str, str] = {
    "file_manager": "autodev.agent.skills.file_manager",
    "code_generator": "autodev.agent.skills.code_generator",
    "code_modifier": "autodev.agent.skills.code_modifier",
    "code_reviewer": "autodev.agent.skills.code_reviewer",
    "test_generator": "autodev.agent.skills.test_generator",
    "dependency_resolver": "autodev.agent.skills.dependency_resolver",
    "schema_inferrer": "autodev.agent.skills.schema_inferrer",
}


@dataclass
class StepResult:
    step_index: int
    success: bool
    abort: bool = False
    output: dict | None = None
    error: str | None = None


class DecisionEngine:
    """Routes plan steps to the appropriate skill module."""

    def __init__(self, context: ContextManager) -> None:
        self.context = context

    async def execute_step(self, step: PlanStep) -> StepResult:
        log.info("engine.step", index=step.index, skill=step.skill)
        module_path = SKILL_REGISTRY.get(step.skill)
        if not module_path:
            log.warning("engine.unknown_skill", skill=step.skill)
            return StepResult(step_index=step.index, success=False, error=f"Unknown skill: {step.skill}")

        try:
            import importlib
            mod = importlib.import_module(module_path)
            skill_fn = getattr(mod, "execute", None)
            if skill_fn is None:
                return StepResult(step_index=step.index, success=False, error="Skill has no execute()")
            output = await skill_fn(step=step, context=self.context)
            return StepResult(step_index=step.index, success=True, output=output)
        except Exception as exc:
            log.error("engine.step.error", index=step.index, error=str(exc))
            return StepResult(step_index=step.index, success=False, error=str(exc))
