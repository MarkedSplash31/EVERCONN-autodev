"""E2E test: full job lifecycle from submission to guard PASS."""

import pytest


@pytest.mark.e2e
class TestFullJobLifecycle:
    @pytest.mark.asyncio
    async def test_job_submit_to_success(self):
        pytest.skip("E2E requires running API and Anthropic key")

    @pytest.mark.asyncio
    async def test_job_guard_blocks_invalid_artifact(self):
        pytest.skip("E2E requires running API and Anthropic key")
