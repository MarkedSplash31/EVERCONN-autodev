"""Unit tests for HashEngine."""

import hashlib
import json
import tempfile
from pathlib import Path

import pytest

from autodev.guard.hash_engine import HashEngine
from autodev.core.constants import HASH_ALGORITHM


class TestHashEngine:
    def setup_method(self):
        self.engine = HashEngine()

    def test_algorithm_constant(self):
        assert self.engine.algorithm == HASH_ALGORITHM
        assert "sha256" in HASH_ALGORITHM

    def test_hash_dict_is_deterministic(self):
        data = {"b": 2, "a": 1, "c": [3, 4]}
        h1 = self.engine.hash_dict(data)
        h2 = self.engine.hash_dict(data)
        assert h1 == h2
        assert len(h1) == 64  # sha256 hex

    def test_hash_dict_sorted_keys(self):
        data1 = {"a": 1, "b": 2}
        data2 = {"b": 2, "a": 1}
        assert self.engine.hash_dict(data1) == self.engine.hash_dict(data2)

    def test_hash_dict_compact_no_spaces(self):
        data = {"key": "value"}
        canonical = json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        expected = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        assert self.engine.hash_dict(data) == expected

    def test_different_data_different_hash(self):
        assert self.engine.hash_dict({"a": 1}) != self.engine.hash_dict({"a": 2})

    def test_hash_file(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".json") as f:
            content = b'{"test": true}'
            f.write(content)
            path = Path(f.name)
        expected = hashlib.sha256(content).hexdigest()
        assert self.engine.hash_file(path) == expected
        path.unlink()

    def test_hash_manifest(self):
        manifest = {"job_id": "abc", "artifacts": {}}
        h = self.engine.hash_manifest(manifest)
        assert h == self.engine.hash_dict(manifest)

    def test_verify_pass(self):
        data = {"x": 42}
        h = self.engine.hash_dict(data)
        assert self.engine.verify(data, h) is True

    def test_verify_fail(self):
        data = {"x": 42}
        assert self.engine.verify(data, "wrong_hash") is False
