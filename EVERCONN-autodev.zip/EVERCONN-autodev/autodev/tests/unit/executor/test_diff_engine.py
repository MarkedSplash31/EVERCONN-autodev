"""Unit tests for DiffEngine."""

import tempfile
from pathlib import Path

import pytest

from autodev.executor.diff_engine import DiffEngine


class TestDiffEngine:
    def test_unified_diff_added_line(self):
        original = "line1\nline2\n"
        modified = "line1\nline2\nline3\n"
        diff = DiffEngine.unified_diff(original, modified, filename="test.py")
        assert "+line3" in diff

    def test_unified_diff_removed_line(self):
        original = "line1\nline2\n"
        modified = "line1\n"
        diff = DiffEngine.unified_diff(original, modified, filename="test.py")
        assert "-line2" in diff

    def test_unified_diff_no_change(self):
        content = "same\n"
        diff = DiffEngine.unified_diff(content, content, filename="test.py")
        assert diff == ""

    def test_has_changes_true(self):
        diff = "--- a/x\n+++ b/x\n@@ -1 +1 @@\n-old\n+new\n"
        assert DiffEngine.has_changes(diff) is True

    def test_has_changes_false(self):
        assert DiffEngine.has_changes("") is False
        assert DiffEngine.has_changes("   \n  ") is False

    def test_count_changed_lines(self):
        diff = "--- a\n+++ b\n@@ -1,2 +1,3 @@\n line1\n-line2\n+line2_modified\n+line3\n"
        counts = DiffEngine.count_changed_lines(diff)
        assert counts["added"] == 2
        assert counts["removed"] == 1
        assert counts["net"] == 1

    def test_diff_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path_a = Path(tmpdir) / "a.py"
            path_b = Path(tmpdir) / "b.py"
            path_a.write_text("x = 1\n")
            path_b.write_text("x = 2\n")
            diff = DiffEngine.diff_files(path_a, path_b)
            assert "-x = 1" in diff
            assert "+x = 2" in diff

    def test_diff_files_missing_original(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path_a = Path(tmpdir) / "missing.py"
            path_b = Path(tmpdir) / "new.py"
            path_b.write_text("new content\n")
            diff = DiffEngine.diff_files(path_a, path_b)
            assert "+new content" in diff
