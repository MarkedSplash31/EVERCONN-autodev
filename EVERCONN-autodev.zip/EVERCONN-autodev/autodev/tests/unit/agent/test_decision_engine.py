"""Unit tests for DecisionEngine."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from autodev.agent.decision_engine import DecisionEngine, StepResult, SKILL_REGISTRY
from autodev.agent.task_planner import PlanStep


class MockContext:
    job_id = "test-job-001"

    def get_history(self):
        return []

    def add_message(self, role, content):
        pass


class TestDecisionEngine:
    def setup_method(self):
        self.engine = DecisionEngine(context=MockContext())

    @pytest.mark.asyncio
    async def test_unknown_skill_returns_error(self):
        step = PlanStep(index=0, skill="nonexistent_skill", description="Do something")
        result = await self.engine.execute_step(step)
        assert result.success is False
        assert "Unknown skill" in (result.error or "")

    @pytest.mark.asyncio
    async def test_known_skill_is_dispatched(self):
        step = PlanStep(index=0, skill="file_manager", description="List files")
        mock_execute = AsyncMock(return_value={"files": []})
        with patch("importlib.import_module") as mock_import:
            mock_module = MagicMock()
            mock_module.execute = mock_execute
            mock_import.return_value = mock_module
            result = await self.engine.execute_step(step)
        assert result.success is True
        assert result.output == {"files": []}

    @pytest.mark.asyncio
    async def test_skill_exception_returns_failed_result(self):
        step = PlanStep(index=1, skill="code_generator", description="Fail")
        with patch("importlib.import_module") as mock_import:
            mock_module = MagicMock()
            mock_module.execute = AsyncMock(side_effect=RuntimeError("boom"))
            mock_import.return_value = mock_module
            result = await self.engine.execute_step(step)
        assert result.success is False
        assert "boom" in (result.error or "")

    def test_all_skills_in_registry(self):
        expected_skills = {
            "file_manager", "code_generator", "code_modifier",
            "code_reviewer", "test_generator", "dependency_resolver", "schema_inferrer"
        }
        assert expected_skills == set(SKILL_REGISTRY.keys())

    @pytest.mark.asyncio
    async def test_abort_flag_not_set_on_normal_failure(self):
        step = PlanStep(index=0, skill="unknown", description="x")
        result = await self.engine.execute_step(step)
        assert result.abort is False
