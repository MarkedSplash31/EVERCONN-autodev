"""Unit tests for TaskPlanner."""

import pytest
from unittest.mock import MagicMock, patch

from autodev.agent.task_planner import TaskPlanner, Plan, PlanStep


class TestTaskPlannerParsing:
    def test_parse_valid_json_steps(self):
        planner = TaskPlanner.__new__(TaskPlanner)
        raw = '[{"skill": "code_generator", "description": "Generate router", "inputs": {}}]'
        steps = planner._parse_steps(raw)
        assert len(steps) == 1
        assert steps[0].skill == "code_generator"
        assert steps[0].description == "Generate router"

    def test_parse_json_embedded_in_prose(self):
        planner = TaskPlanner.__new__(TaskPlanner)
        raw = 'Here is the plan:\n[{"skill": "file_manager", "description": "Read file"}]'
        steps = planner._parse_steps(raw)
        assert len(steps) == 1
        assert steps[0].skill == "file_manager"

    def test_parse_invalid_json_returns_fallback(self):
        planner = TaskPlanner.__new__(TaskPlanner)
        raw = "This is not JSON at all"
        steps = planner._parse_steps(raw)
        assert len(steps) == 1
        assert steps[0].skill == "code_generator"

    def test_parse_malformed_json_returns_fallback(self):
        planner = TaskPlanner.__new__(TaskPlanner)
        raw = "[{broken json"
        steps = planner._parse_steps(raw)
        assert len(steps) == 1

    def test_parse_multiple_steps_preserves_order(self):
        planner = TaskPlanner.__new__(TaskPlanner)
        raw = '[{"skill": "code_generator", "description": "Step 1"}, {"skill": "test_generator", "description": "Step 2"}]'
        steps = planner._parse_steps(raw)
        assert len(steps) == 2
        assert steps[0].index == 0
        assert steps[1].index == 1

    def test_parse_step_with_inputs(self):
        planner = TaskPlanner.__new__(TaskPlanner)
        raw = '[{"skill": "file_manager", "description": "Read config", "inputs": {"op": "read", "path": "config.yaml"}}]'
        steps = planner._parse_steps(raw)
        assert steps[0].inputs == {"op": "read", "path": "config.yaml"}

    def test_plan_dataclass(self):
        steps = [PlanStep(index=0, skill="code_generator", description="Test")]
        plan = Plan(steps=steps, raw_response="raw")
        assert len(plan.steps) == 1
        assert plan.raw_response == "raw"
