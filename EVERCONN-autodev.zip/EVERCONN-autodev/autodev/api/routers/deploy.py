"""Deployment pipeline endpoints."""

from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()


class DeployRequest(BaseModel):
    job_id: str
    target: str = "local_docker"   # local_docker | remote_ssh | vercel


@router.post("/")
async def trigger_deploy(req: DeployRequest):
    """Trigger deployment pipeline for a completed job."""
    return {"job_id": req.job_id, "target": req.target, "status": "queued"}


@router.get("/{job_id}/status")
async def deploy_status(job_id: str):
    """Get deployment status for a job."""
    return {"job_id": job_id, "stages": []}
