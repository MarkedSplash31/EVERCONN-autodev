"""Application settings — loaded from environment / .env file."""

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Server
    autodev_host: str = "0.0.0.0"
    autodev_port: int = 8000
    autodev_env: str = "development"

    # Anthropic
    anthropic_api_key: str = Field(default="", alias="ANTHROPIC_API_KEY")
    anthropic_model: str = "claude-sonnet-4-6"

    # Paths
    runtime_dir: Path = Path("runtime")
    artifacts_dir: Path = Path("contracts/runtime/artifacts")
    guard_policy_path: Path = Path("contracts/runtime/policy.yaml")
    guard_schema_dir: Path = Path("contracts/runtime/schemas")

    # Pinecone
    pinecone_api_key: str = ""
    pinecone_index: str = "autodev-memory"
    pinecone_env: str = "us-east-1-aws"

    # Deployer
    docker_host: str = "unix:///var/run/docker.sock"
    vercel_token: str = ""
    ssh_deploy_host: str = ""
    ssh_deploy_user: str = "deploy"
    ssh_deploy_key_path: str = "~/.ssh/id_ed25519"

    # Notifications
    slack_webhook_url: str = ""

    @property
    def is_production(self) -> bool:
        return self.autodev_env == "production"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
