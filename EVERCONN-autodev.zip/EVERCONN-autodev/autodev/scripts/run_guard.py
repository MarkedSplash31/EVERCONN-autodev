"""CLI entrypoint: run the runtime guard for a specific job."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import typer

app = typer.Typer()


@app.command()
def main(
    job_id: str = typer.Option(..., "--job-id", "-j", help="Job ID to guard"),
    runtime_dir: str = typer.Option("runtime", help="Runtime directory"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
):
    """Run runtime guard verification for a job and print the result."""
    from autodev.guard.guard_runner import GuardRunner

    job_dir = Path(runtime_dir) / "jobs" / job_id
    if not job_dir.exists():
        typer.echo(f"[error] Job directory not found: {job_dir}", err=True)
        raise typer.Exit(1)

    runner = GuardRunner(job_id=job_id)
    report = runner.run(job_dir)

    output = {
        "job_id": report.job_id,
        "passed": report.passed,
        "violations": [
            {"rule": v.rule, "severity": v.severity, "message": v.message}
            for v in report.violations
        ],
        "artifact_path": str(report.artifact_path) if report.artifact_path else None,
        "verification_hash": report.verification_hash,
    }

    if verbose:
        typer.echo(json.dumps(output, indent=2))
    else:
        status = "PASS" if report.passed else "FAIL"
        typer.echo(f"Guard {status} — job_id={job_id}")
        if not report.passed:
            for v in report.violations:
                if v.severity in ("critical", "error"):
                    typer.echo(f"  [{v.severity}] {v.rule}: {v.message}", err=True)

    raise typer.Exit(0 if report.passed else 1)


if __name__ == "__main__":
    app()
