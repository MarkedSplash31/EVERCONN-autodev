"""Initialize the autodev workspace — creates runtime dirs and validates config."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import typer

app = typer.Typer()


@app.command()
def main(
    runtime_dir: str = typer.Option("runtime", help="Runtime directory path"),
    artifacts_dir: str = typer.Option("contracts/runtime/artifacts", help="Artifacts directory"),
):
    """Initialize workspace directories and validate environment."""
    dirs = [
        Path(runtime_dir) / "jobs",
        Path(artifacts_dir),
        Path("autodev/sandbox/workspace"),
        Path("autodev/sandbox/snapshots"),
        Path("autodev/policies/users"),
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
        typer.echo(f"  [ok] {d}")

    # Validate .env exists
    if not Path(".env").exists():
        typer.echo("[warn] .env not found — copy .env.example and fill in values", err=True)
    else:
        typer.echo("  [ok] .env found")

    # Write empty active_jobs.json if missing
    active_jobs = Path(runtime_dir) / "active_jobs.json"
    if not active_jobs.exists():
        active_jobs.write_text(json.dumps({"jobs": []}, indent=2))
        typer.echo(f"  [ok] {active_jobs} created")

    typer.echo("\nWorkspace initialized.")


if __name__ == "__main__":
    app()
