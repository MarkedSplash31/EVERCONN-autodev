# EVERCONN-autodev

Autonomous development agent with runtime guard, sandbox execution, and structured deployment pipeline.

## Quick start

```bash
cp .env.example .env
# fill in .env
make install
make dev
```

## Architecture

| Layer | Description |
|-------|-------------|
| `autodev/agent` | Claude-powered task planner and decision engine |
| `autodev/guard` | Runtime integrity verification against JSON schemas |
| `autodev/executor` | Command runner, diff engine, rollback manager |
| `autodev/deployer` | Multi-stage deploy pipeline (lint → test → build → guard → push) |
| `autodev/api` | FastAPI HTTP interface |
| `autodev/sandbox` | Jailed workspace with Jinja2 templates |

## Key concepts

- **Guard PASS** — required before any artifact is written to `contracts/runtime/artifacts/`
- **Schemas** — live in `contracts/runtime/schemas/`, validated with `jsonschema`
- **Policy** — `contracts/runtime/policy.yaml` controls severity rules and allowed operations
- **Job lifecycle** — `RUNNING → SUCCESS | FAILED | ABORTED | TRUNCATED | SKIPPED`

## Docs

- [Architecture](docs/architecture.md)
- [Guard system](docs/guard_system.md)
- [Agent flows](docs/agent_flows.md)
- [API reference](docs/api_reference.md)
