#!/usr/bin/env bash
# Backup verified artifacts to remote storage
set -euo pipefail

ARTIFACTS_DIR="${ARTIFACTS_DIR:-contracts/runtime/artifacts}"
BACKUP_DEST="${BACKUP_DEST:-s3://everconn-backups/artifacts}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo "[backup] Starting artifact backup at $TIMESTAMP"
echo "[backup] Source: $ARTIFACTS_DIR"
echo "[backup] Dest:   $BACKUP_DEST/$TIMESTAMP"

if command -v aws &>/dev/null; then
    aws s3 sync "$ARTIFACTS_DIR" "$BACKUP_DEST/$TIMESTAMP" --no-progress
    echo "[backup] Done (S3)"
elif command -v rsync &>/dev/null && [[ -n "${BACKUP_SSH_HOST:-}" ]]; then
    rsync -az "$ARTIFACTS_DIR/" "$BACKUP_SSH_HOST:$BACKUP_DEST/$TIMESTAMP/"
    echo "[backup] Done (rsync)"
else
    echo "[backup] No backup provider configured (set BACKUP_DEST or BACKUP_SSH_HOST)"
    exit 1
fi
