"""Seed Pinecone index with initial long-term memory entries."""

import typer

app = typer.Typer()


@app.command()
def main(
    index: str = typer.Option("autodev-memory", help="Pinecone index name"),
    dry_run: bool = typer.Option(False, "--dry-run"),
):
    """Seed the Pinecone vector store with baseline memory entries."""
    typer.echo(f"Seeding index: {index} (dry_run={dry_run})")
    # TODO: implement seeding logic
    typer.echo("Done.")


if __name__ == "__main__":
    app()
