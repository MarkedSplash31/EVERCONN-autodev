# Automation

Workflow definitions and credentials for EVERCONN-autodev automation.

## Workflows

| File | Description |
|------|-------------|
| `job_trigger.json` | HTTP webhook → create autodev job |
| `guard_webhook.json` | job.completed event → run guard → notify |
| `deploy_notify.json` | deploy.completed event → Slack notification |
| `lead_capture.json` | Form submission → CRM + Slack |

## Credentials

Store credential files in `credentials/`. This directory is gitignored.
Only `.gitkeep` is versioned. Never commit real keys or tokens here.
