"""Generate unified diffs between original and modified file content."""

from __future__ import annotations

import difflib
from pathlib import Path

import structlog

log = structlog.get_logger(__name__)


class DiffEngine:
    """Produce unified diffs and apply patches."""

    @staticmethod
    def unified_diff(original: str, modified: str, filename: str = "file") -> str:
        lines_a = original.splitlines(keepends=True)
        lines_b = modified.splitlines(keepends=True)
        diff = difflib.unified_diff(lines_a, lines_b, fromfile=f"a/{filename}", tofile=f"b/{filename}")
        return "".join(diff)

    @staticmethod
    def diff_files(path_a: Path, path_b: Path) -> str:
        original = path_a.read_text(encoding="utf-8") if path_a.exists() else ""
        modified = path_b.read_text(encoding="utf-8") if path_b.exists() else ""
        return DiffEngine.unified_diff(original, modified, filename=path_a.name)

    @staticmethod
    def has_changes(diff: str) -> bool:
        return bool(diff.strip())

    @staticmethod
    def count_changed_lines(diff: str) -> dict:
        added = sum(1 for line in diff.splitlines() if line.startswith("+") and not line.startswith("+++"))
        removed = sum(1 for line in diff.splitlines() if line.startswith("-") and not line.startswith("---"))
        return {"added": added, "removed": removed, "net": added - removed}
