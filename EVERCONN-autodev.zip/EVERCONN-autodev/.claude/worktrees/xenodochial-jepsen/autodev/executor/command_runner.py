"""Run shell commands within the sandboxed workspace and capture output."""

from __future__ import annotations

import asyncio
import shlex
from dataclasses import dataclass
from pathlib import Path

import structlog

from autodev.core.exceptions import SandboxError

log = structlog.get_logger(__name__)

FORBIDDEN_COMMANDS = {"rm", "rmdir", "del", "format", "dd", "mkfs", "shutdown", "reboot"}


@dataclass
class CommandResult:
    command: str
    returncode: int
    stdout: str
    stderr: str

    @property
    def success(self) -> bool:
        return self.returncode == 0


class CommandRunner:
    """Execute commands inside a restricted working directory."""

    def __init__(self, work_dir: Path, timeout: float = 30.0) -> None:
        self.work_dir = work_dir
        self.timeout = timeout

    async def run(self, command: str, env: dict | None = None) -> CommandResult:
        parts = shlex.split(command)
        if parts and parts[0] in FORBIDDEN_COMMANDS:
            raise SandboxError(f"Forbidden command: {parts[0]!r}")

        log.info("command_runner.run", command=command, cwd=str(self.work_dir))
        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.work_dir,
                env=env,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=self.timeout)
            result = CommandResult(
                command=command,
                returncode=proc.returncode or 0,
                stdout=stdout.decode("utf-8", errors="replace"),
                stderr=stderr.decode("utf-8", errors="replace"),
            )
            log.info("command_runner.done", returncode=result.returncode)
            return result
        except asyncio.TimeoutError:
            raise SandboxError(f"Command timed out after {self.timeout}s: {command!r}")
