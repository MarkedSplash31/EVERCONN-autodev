"""Immutable append-only audit log for all agent actions."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

import structlog

log = structlog.get_logger(__name__)


class AuditLog:
    """Append-only structured log. Each entry is one JSONL line."""

    def __init__(self, log_path: Path) -> None:
        self.log_path = log_path
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

    def record(self, action: str, actor: str = "agent", **kwargs) -> dict:
        entry = {
            "ts": datetime.now(UTC).isoformat(),
            "action": action,
            "actor": actor,
            **kwargs,
        }
        with self.log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry, default=str, ensure_ascii=False) + "\n")
        log.debug("audit_log.record", action=action)
        return entry

    def read_all(self) -> list[dict]:
        if not self.log_path.exists():
            return []
        entries = []
        for line in self.log_path.read_text(encoding="utf-8").splitlines():
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        return entries
