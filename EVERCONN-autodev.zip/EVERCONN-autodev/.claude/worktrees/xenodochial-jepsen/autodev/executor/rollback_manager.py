"""Rollback manager — restores files from snapshots on job failure."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import structlog

log = structlog.get_logger(__name__)


class RollbackManager:
    """Takes snapshots before writes and restores on rollback."""

    def __init__(self, snapshot_dir: Path) -> None:
        self.snapshot_dir = snapshot_dir
        self.snapshot_dir.mkdir(parents=True, exist_ok=True)
        self._snapshots: dict[str, Path] = {}

    def snapshot(self, file_path: Path) -> Path | None:
        if not file_path.exists():
            return None
        snap_path = self.snapshot_dir / file_path.name
        shutil.copy2(file_path, snap_path)
        self._snapshots[str(file_path)] = snap_path
        log.debug("rollback.snapshot", path=str(file_path))
        return snap_path

    def rollback(self, file_path: Path) -> bool:
        snap = self._snapshots.get(str(file_path))
        if snap is None or not snap.exists():
            log.warning("rollback.no_snapshot", path=str(file_path))
            return False
        shutil.copy2(snap, file_path)
        log.info("rollback.restored", path=str(file_path))
        return True

    def rollback_all(self) -> int:
        count = 0
        for path_str, snap in self._snapshots.items():
            path = Path(path_str)
            if snap.exists():
                shutil.copy2(snap, path)
                count += 1
        log.info("rollback.all_restored", count=count)
        return count

    def clear(self) -> None:
        shutil.rmtree(self.snapshot_dir, ignore_errors=True)
        self.snapshot_dir.mkdir(parents=True, exist_ok=True)
        self._snapshots.clear()
