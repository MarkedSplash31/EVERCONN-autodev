"""Watch filesystem paths for changes and emit events."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from pathlib import Path

import structlog

log = structlog.get_logger(__name__)


class FsWatcher:
    """Async filesystem watcher using watchfiles."""

    def __init__(self, paths: list[Path]) -> None:
        self.paths = paths
        self._running = False

    async def watch(self) -> AsyncIterator[list[tuple[str, str]]]:
        """Yield batches of (change_type, path) tuples."""
        try:
            from watchfiles import awatch, Change

            self._running = True
            async for changes in awatch(*self.paths):
                if not self._running:
                    break
                batch = []
                for change, path in changes:
                    change_type = {
                        Change.added: "added",
                        Change.modified: "modified",
                        Change.deleted: "deleted",
                    }.get(change, "unknown")
                    batch.append((change_type, path))
                    log.debug("fs_watcher.change", type=change_type, path=path)
                yield batch
        except ImportError:
            log.warning("fs_watcher.watchfiles_not_installed")

    def stop(self) -> None:
        self._running = False
