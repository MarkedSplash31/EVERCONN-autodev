"""Structured event emitter — writes JSONL events for job audit trail."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

import structlog

log = structlog.get_logger(__name__)


class EventEmitter:
    """Appends structured events to a job's events.jsonl file."""

    def __init__(self, events_path: Path) -> None:
        self.events_path = events_path
        self.events_path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, event_type: str, data: dict | None = None) -> dict:
        event = {
            "ts": datetime.now(UTC).isoformat(),
            "type": event_type,
            **(data or {}),
        }
        with self.events_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")
        log.debug("event_emitter.emit", type=event_type)
        return event

    def emit_step_start(self, step_index: int, skill: str) -> dict:
        return self.emit("step_start", {"step_index": step_index, "skill": skill})

    def emit_step_end(self, step_index: int, success: bool, error: str | None = None) -> dict:
        data: dict = {"step_index": step_index, "success": success}
        if error:
            data["error"] = error
        return self.emit("step_end", data)

    def emit_guard_result(self, passed: bool, violations: list) -> dict:
        return self.emit("guard_result", {"passed": passed, "violations": violations})
