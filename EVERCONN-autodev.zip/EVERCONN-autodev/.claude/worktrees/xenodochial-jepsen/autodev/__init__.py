"""EVERCONN autodev — autonomous development agent."""

__version__ = "0.1.0"
