"""Skill: generate pytest test suites for given source code."""

from __future__ import annotations

import anthropic
import structlog

from autodev.agent.context_manager import ContextManager
from autodev.agent.task_planner import PlanStep
from autodev.core.config import get_settings

log = structlog.get_logger(__name__)


async def execute(step: PlanStep, context: ContextManager) -> dict:
    settings = get_settings()
    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)

    source_code = step.inputs.get("source_code", "")
    module_name = step.inputs.get("module_name", "module")

    system_prompt = (
        "You are a test engineer. Generate comprehensive pytest tests. "
        "Use pytest-asyncio for async functions. Return only the test file content."
    )
    user_msg = f"Generate tests for `{module_name}`:\n```python\n{source_code}\n```"

    response = client.messages.create(
        model=settings.anthropic_model,
        max_tokens=4096,
        system=system_prompt,
        messages=[{"role": "user", "content": user_msg}],
    )
    tests = response.content[0].text
    log.info("test_generator.done", chars=len(tests))
    return {"tests": tests, "module": module_name}
