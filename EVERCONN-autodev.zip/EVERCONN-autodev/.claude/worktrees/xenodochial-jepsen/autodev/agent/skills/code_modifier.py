"""Skill: apply targeted modifications to existing code via Claude."""

from __future__ import annotations

import anthropic
import structlog

from autodev.agent.context_manager import ContextManager
from autodev.agent.task_planner import PlanStep
from autodev.core.config import get_settings

log = structlog.get_logger(__name__)


async def execute(step: PlanStep, context: ContextManager) -> dict:
    settings = get_settings()
    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)

    original = step.inputs.get("original_code", "")
    instruction = step.description

    try:
        system_prompt = open("autodev/agent/prompts/code_modify.txt").read()
    except FileNotFoundError:
        system_prompt = "You are a code modifier. Apply the requested change and return only the modified code."

    user_msg = f"ORIGINAL CODE:\n```\n{original}\n```\n\nMODIFICATION: {instruction}"
    response = client.messages.create(
        model=settings.anthropic_model,
        max_tokens=4096,
        system=system_prompt,
        messages=[{"role": "user", "content": user_msg}],
    )
    modified = response.content[0].text
    log.info("code_modifier.done", chars=len(modified))
    return {"modified_code": modified}
