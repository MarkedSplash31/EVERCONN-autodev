"""Skill: generate new code via Claude using the code_gen prompt."""

from __future__ import annotations

import anthropic
import structlog

from autodev.agent.context_manager import ContextManager
from autodev.agent.task_planner import PlanStep
from autodev.core.config import get_settings

log = structlog.get_logger(__name__)


async def execute(step: PlanStep, context: ContextManager) -> dict:
    settings = get_settings()
    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)

    try:
        system_prompt = open("autodev/agent/prompts/code_gen.txt").read()
    except FileNotFoundError:
        system_prompt = "You are an expert software engineer. Generate clean, production-ready code."

    messages = context.get_history() + [{"role": "user", "content": step.description}]

    response = client.messages.create(
        model=settings.anthropic_model,
        max_tokens=4096,
        system=system_prompt,
        messages=messages,
    )
    generated = response.content[0].text
    context.add_message("assistant", generated)
    log.info("code_generator.done", chars=len(generated))
    return {"code": generated}
