"""In-memory codebase index — maps file paths to summaries for context injection."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import structlog

log = structlog.get_logger(__name__)


@dataclass
class FileEntry:
    path: str
    language: str
    summary: str = ""
    exports: list[str] = field(default_factory=list)
    size_bytes: int = 0


class CodebaseIndex:
    """Lightweight index of the project's source files."""

    def __init__(self) -> None:
        self._entries: dict[str, FileEntry] = {}

    def index_directory(self, root: Path, extensions: list[str] | None = None) -> int:
        if extensions is None:
            extensions = [".py", ".ts", ".tsx", ".js", ".jsx"]
        count = 0
        for path in root.rglob("*"):
            if path.is_file() and path.suffix in extensions:
                self._entries[str(path)] = FileEntry(
                    path=str(path),
                    language=path.suffix.lstrip("."),
                    size_bytes=path.stat().st_size,
                )
                count += 1
        log.info("codebase_index.indexed", root=str(root), files=count)
        return count

    def get(self, path: str) -> FileEntry | None:
        return self._entries.get(path)

    def search(self, query: str) -> list[FileEntry]:
        q = query.lower()
        return [e for e in self._entries.values() if q in e.path.lower() or q in e.summary.lower()]

    def all_paths(self) -> list[str]:
        return list(self._entries.keys())
