"""Short-term per-job memory — persisted to runtime/jobs/<job_id>/."""

from __future__ import annotations

import json
from pathlib import Path

import structlog

from autodev.core.config import get_settings

log = structlog.get_logger(__name__)


class JobMemory:
    """Read/write structured data for a single job execution."""

    def __init__(self, job_id: str) -> None:
        self.job_id = job_id
        settings = get_settings()
        self.job_dir = settings.runtime_dir / "jobs" / job_id
        self.job_dir.mkdir(parents=True, exist_ok=True)

    def write(self, artifact_name: str, data: dict) -> Path:
        path = self.job_dir / f"{artifact_name}.json"
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        log.debug("job_memory.write", job_id=self.job_id, artifact=artifact_name)
        return path

    def read(self, artifact_name: str) -> dict | None:
        path = self.job_dir / f"{artifact_name}.json"
        if not path.exists():
            return None
        return json.loads(path.read_text(encoding="utf-8"))

    def append_event(self, event: dict) -> None:
        path = self.job_dir / "events.jsonl"
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")

    def list_artifacts(self) -> list[str]:
        return [p.name for p in self.job_dir.iterdir() if p.is_file()]
