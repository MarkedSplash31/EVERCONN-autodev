"""Long-term memory backed by Pinecone vector store."""

from __future__ import annotations

import structlog

from autodev.core.config import get_settings

log = structlog.get_logger(__name__)


class LongtermMemory:
    """Semantic memory using Pinecone + Claude embeddings."""

    def __init__(self) -> None:
        self.settings = get_settings()
        self._index = None

    def _get_index(self):
        if self._index is not None:
            return self._index
        try:
            from pinecone import Pinecone

            pc = Pinecone(api_key=self.settings.pinecone_api_key)
            self._index = pc.Index(self.settings.pinecone_index)
        except ImportError:
            log.warning("longterm_memory.pinecone_not_installed")
        except Exception as exc:
            log.error("longterm_memory.init_error", error=str(exc))
        return self._index

    async def store(self, key: str, content: str, metadata: dict | None = None) -> bool:
        index = self._get_index()
        if index is None:
            return False
        log.info("longterm_memory.store", key=key, chars=len(content))
        # TODO: embed content and upsert
        return True

    async def search(self, query: str, top_k: int = 5) -> list[dict]:
        index = self._get_index()
        if index is None:
            return []
        log.info("longterm_memory.search", query=query[:60])
        # TODO: embed query and query index
        return []
