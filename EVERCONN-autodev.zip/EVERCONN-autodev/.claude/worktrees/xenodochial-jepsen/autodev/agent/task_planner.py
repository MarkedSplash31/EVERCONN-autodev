"""Task decomposition via Claude — turns a natural language description into a step plan."""

from __future__ import annotations

from dataclasses import dataclass, field

import anthropic
import structlog

from autodev.agent.context_manager import ContextManager
from autodev.core.config import get_settings

log = structlog.get_logger(__name__)


@dataclass
class PlanStep:
    index: int
    skill: str
    description: str
    inputs: dict = field(default_factory=dict)


@dataclass
class Plan:
    steps: list[PlanStep]
    raw_response: str = ""


class TaskPlanner:
    """Decomposes a high-level task description into ordered PlanSteps."""

    def __init__(self, context: ContextManager) -> None:
        self.context = context
        self.settings = get_settings()
        self._client = anthropic.Anthropic(api_key=self.settings.anthropic_api_key)

    async def decompose(self, description: str) -> Plan:
        log.info("planner.decompose", description=description[:80])
        # Load system prompt from disk
        prompt_path = "autodev/agent/prompts/plan_decomposition.txt"
        try:
            system_prompt = open(prompt_path).read()
        except FileNotFoundError:
            system_prompt = "You are a task planner. Return a JSON list of steps."

        message = self._client.messages.create(
            model=self.settings.anthropic_model,
            max_tokens=2048,
            system=system_prompt,
            messages=[{"role": "user", "content": description}],
        )
        raw = message.content[0].text
        steps = self._parse_steps(raw)
        return Plan(steps=steps, raw_response=raw)

    def _parse_steps(self, raw: str) -> list[PlanStep]:
        import json, re

        match = re.search(r"\[.*\]", raw, re.DOTALL)
        if not match:
            return [PlanStep(index=0, skill="code_generator", description=raw)]
        try:
            data = json.loads(match.group())
            return [
                PlanStep(
                    index=i,
                    skill=s.get("skill", "code_generator"),
                    description=s.get("description", ""),
                    inputs=s.get("inputs", {}),
                )
                for i, s in enumerate(data)
            ]
        except json.JSONDecodeError:
            return [PlanStep(index=0, skill="code_generator", description=raw)]
