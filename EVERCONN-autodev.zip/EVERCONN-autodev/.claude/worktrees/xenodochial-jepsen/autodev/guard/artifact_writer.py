"""Write verified artifacts to contracts/runtime/artifacts/ after guard PASS."""

from __future__ import annotations

import json
import shutil
from datetime import UTC, datetime
from pathlib import Path

import structlog

from autodev.core.constants import VERIFIER_NAME

log = structlog.get_logger(__name__)


class ArtifactWriter:
    """Writes job artifacts to the contracts artifacts directory on guard PASS."""

    def __init__(self, job_id: str, artifacts_dir: Path) -> None:
        self.job_id = job_id
        self.artifacts_dir = Path(artifacts_dir)

    def write(self, job_dir: Path, manifest: dict, verification_hash: str) -> Path:
        dest = self.artifacts_dir / f"autodev-{self.job_id}"
        dest.mkdir(parents=True, exist_ok=True)

        # Copy all artifact files
        for entry in manifest.get("artifacts", {}).values():
            src = job_dir / entry["filename"]
            if src.exists():
                shutil.copy2(src, dest / entry["filename"])

        # Write verification receipt
        receipt = {
            "job_id": self.job_id,
            "sealed_at": datetime.now(UTC).isoformat(),
            "verifier": {"name": VERIFIER_NAME, "version": "1.0"},
            "manifest_hash": verification_hash,
        }
        receipt_path = dest / "guard_receipt.json"
        receipt_path.write_text(json.dumps(receipt, indent=2, ensure_ascii=False), encoding="utf-8")

        log.info("artifact_writer.written", job_id=self.job_id, dest=str(dest))
        return dest
