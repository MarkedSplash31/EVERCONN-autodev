"""Hash engine — sha256 over JSON with sorted keys, compact UTF-8 encoding."""

from __future__ import annotations

import hashlib
import json

from autodev.core.constants import HASH_ALGORITHM


class HashEngine:
    """Produces deterministic sha256 hashes over JSON-serializable data."""

    algorithm = HASH_ALGORITHM

    def hash_dict(self, data: dict) -> str:
        """Serialize to compact sorted-key JSON (UTF-8) and return hex sha256."""
        canonical = json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def hash_file(self, path) -> str:
        """Return sha256 of raw file bytes."""
        import pathlib
        data = pathlib.Path(path).read_bytes()
        return hashlib.sha256(data).hexdigest()

    def hash_manifest(self, manifest: dict) -> str:
        """Hash the manifest dict deterministically."""
        return self.hash_dict(manifest)

    def verify(self, data: dict, expected_hash: str) -> bool:
        return self.hash_dict(data) == expected_hash
