"""Resolve rule severity from the policy's severity_map."""

from __future__ import annotations

import structlog

log = structlog.get_logger(__name__)

DEFAULT_SEVERITY = "warning"


class SeverityResolver:
    """Maps rule names to severity levels using the loaded policy."""

    def __init__(self, policy: dict) -> None:
        self.severity_map: dict[str, str] = policy.get("severity_map", {})
        self.blocking_severities: list[str] = policy.get("blocking_severities", ["critical", "error"])

    def resolve(self, rule: str) -> str:
        sev = self.severity_map.get(rule, DEFAULT_SEVERITY)
        log.debug("severity_resolver.resolve", rule=rule, severity=sev)
        return sev

    def is_blocking(self, rule: str) -> bool:
        return self.resolve(rule) in self.blocking_severities

    def is_blocking_severity(self, severity: str) -> bool:
        return severity in self.blocking_severities
