"""FastAPI application entry point."""

from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from autodev.api.routers import deploy, guard, jobs, policies, sandbox
from autodev.core.config import get_settings

log = structlog.get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    log.info("autodev.startup", env=settings.autodev_env, model=settings.anthropic_model)
    yield
    log.info("autodev.shutdown")


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title="EVERCONN autodev",
        version="0.1.0",
        description="Autonomous development agent API",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"] if not settings.is_production else [],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(jobs.router, prefix="/jobs", tags=["jobs"])
    app.include_router(sandbox.router, prefix="/sandbox", tags=["sandbox"])
    app.include_router(deploy.router, prefix="/deploy", tags=["deploy"])
    app.include_router(policies.router, prefix="/policies", tags=["policies"])
    app.include_router(guard.router, prefix="/guard", tags=["guard"])

    @app.get("/health")
    async def health():
        return {"status": "ok", "version": "0.1.0"}

    return app


app = create_app()
