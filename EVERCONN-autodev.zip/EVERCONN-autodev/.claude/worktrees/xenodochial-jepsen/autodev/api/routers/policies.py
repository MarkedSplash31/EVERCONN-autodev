"""Policy management endpoints."""

from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def list_policies():
    """List active policies."""
    return {"policies": ["default_policy"]}


@router.get("/{policy_name}")
async def get_policy(policy_name: str):
    """Get policy details."""
    return {"name": policy_name}
