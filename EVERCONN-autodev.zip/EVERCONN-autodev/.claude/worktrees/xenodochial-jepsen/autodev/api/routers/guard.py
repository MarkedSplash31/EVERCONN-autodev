"""Guard verification endpoints."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()


class GuardRunRequest(BaseModel):
    job_id: str
    policy: str = "default"


class GuardResult(BaseModel):
    job_id: str
    passed: bool
    violations: list[dict] = []
    artifact_path: str | None = None


@router.post("/run", response_model=GuardResult)
async def run_guard(req: GuardRunRequest):
    """Run runtime guard verification for a job."""
    # TODO: invoke guard_runner
    return GuardResult(job_id=req.job_id, passed=True)


@router.get("/{job_id}/result", response_model=GuardResult)
async def get_guard_result(job_id: str):
    """Get stored guard result for a job."""
    raise HTTPException(status_code=404, detail=f"No guard result for job {job_id!r}")
