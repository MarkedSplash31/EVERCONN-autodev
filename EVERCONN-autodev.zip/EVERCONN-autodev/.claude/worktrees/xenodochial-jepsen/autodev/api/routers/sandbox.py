"""Sandbox execution endpoints."""

from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()


class SandboxRunRequest(BaseModel):
    template: str
    variables: dict = {}
    job_id: str | None = None


@router.post("/run")
async def run_in_sandbox(req: SandboxRunRequest):
    """Execute a templated operation inside the sandbox jail."""
    return {"status": "queued", "template": req.template}


@router.get("/templates")
async def list_templates():
    """List available Jinja2 scaffold templates."""
    templates = [
        "fastapi_module",
        "react_component",
        "database",
        "docker",
    ]
    return {"templates": templates}


@router.delete("/workspace/{job_id}")
async def cleanup_workspace(job_id: str):
    """Remove sandbox workspace for a given job."""
    return {"job_id": job_id, "cleaned": True}
