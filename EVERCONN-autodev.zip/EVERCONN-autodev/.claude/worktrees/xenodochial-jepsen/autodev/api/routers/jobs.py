"""Job management endpoints."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from autodev.core.constants import JOB_STATES
from autodev.core.exceptions import JobNotFoundError

router = APIRouter()


class JobCreateRequest(BaseModel):
    description: str
    context: dict = {}


class JobResponse(BaseModel):
    job_id: str
    state: str
    description: str


@router.post("/", response_model=JobResponse, status_code=202)
async def create_job(req: JobCreateRequest):
    """Submit a new autonomous development job."""
    import uuid

    job_id = str(uuid.uuid4())
    # TODO: enqueue job to agent
    return JobResponse(job_id=job_id, state="RUNNING", description=req.description)


@router.get("/{job_id}", response_model=JobResponse)
async def get_job(job_id: str):
    """Get job status."""
    raise HTTPException(status_code=404, detail=f"Job {job_id!r} not found")


@router.get("/")
async def list_jobs(state: str | None = None):
    """List all jobs, optionally filtered by state."""
    if state and state not in JOB_STATES:
        raise HTTPException(status_code=400, detail=f"Invalid state. Must be one of {JOB_STATES}")
    return {"jobs": []}


@router.post("/{job_id}/abort")
async def abort_job(job_id: str):
    """Abort a running job."""
    return {"job_id": job_id, "state": "ABORTED"}
