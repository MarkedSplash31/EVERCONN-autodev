"""Stage: guard_verify — BLOCKING stage; no artifact may be pushed without PASS."""

from __future__ import annotations

from pathlib import Path

import structlog

from autodev.core.config import get_settings
from autodev.core.exceptions import DeployError
from autodev.guard.guard_runner import GuardRunner

log = structlog.get_logger(__name__)


async def run(job_id: str, job_dir: Path, target: str) -> dict:
    log.info("stage_guard_verify.run", job_id=job_id)
    settings = get_settings()
    runner = GuardRunner(job_id=job_id)
    report = runner.run(job_dir)

    if not report.passed:
        blocking = [v for v in report.violations if v.severity in ("critical", "error")]
        summary = "; ".join(f"[{v.severity}] {v.rule}: {v.message}" for v in blocking)
        raise DeployError("guard_verify", f"Guard FAILED — {len(blocking)} blocking violation(s): {summary}")

    log.info("stage_guard_verify.pass", job_id=job_id, artifact=str(report.artifact_path))
    return {
        "guard": "pass",
        "artifact_path": str(report.artifact_path),
        "hash": report.verification_hash,
    }
