"""Stage: push — push build artifact to the deployment target."""

from __future__ import annotations

from pathlib import Path

import structlog

from autodev.core.exceptions import DeployError
from autodev.deployer.targets import local_docker, remote_ssh, vercel_api

log = structlog.get_logger(__name__)

TARGET_MAP = {
    "local_docker": local_docker,
    "remote_ssh": remote_ssh,
    "vercel": vercel_api,
}


async def run(job_id: str, job_dir: Path, target: str) -> dict:
    log.info("stage_push.run", job_id=job_id, target=target)
    module = TARGET_MAP.get(target)
    if module is None:
        raise DeployError("push", f"Unknown target: {target!r}")
    return await module.push(job_id=job_id, job_dir=job_dir)
