"""Stage: lint — run ruff on generated Python source."""

from __future__ import annotations

import asyncio
from pathlib import Path

from autodev.core.exceptions import DeployError


async def run(job_id: str, job_dir: Path, target: str) -> dict:
    proc = await asyncio.create_subprocess_shell(
        "ruff check .",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=job_dir,
    )
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise DeployError("lint", stderr.decode("utf-8", errors="replace"))
    return {"lint": "pass", "output": stdout.decode("utf-8", errors="replace")}
