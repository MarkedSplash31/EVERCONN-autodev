"""Deploy target: local Docker daemon."""

from __future__ import annotations

import asyncio
from pathlib import Path

import structlog

from autodev.core.config import get_settings
from autodev.core.exceptions import DeployError

log = structlog.get_logger(__name__)


async def push(job_id: str, job_dir: Path) -> dict:
    settings = get_settings()
    tag = f"autodev-{job_id[:8]}:latest"
    log.info("local_docker.push", image=tag)

    env = {"DOCKER_HOST": settings.docker_host} if settings.docker_host else None
    proc = await asyncio.create_subprocess_shell(
        f"docker run -d --name autodev-{job_id[:8]} {tag}",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
    )
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise DeployError("push", f"docker run failed: {stderr.decode('utf-8', errors='replace')}")

    container_id = stdout.decode("utf-8").strip()
    log.info("local_docker.started", container=container_id)
    return {"target": "local_docker", "container_id": container_id, "image": tag}
