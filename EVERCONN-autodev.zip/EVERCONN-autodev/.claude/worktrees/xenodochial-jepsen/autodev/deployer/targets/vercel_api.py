"""Deploy target: Vercel via REST API."""

from __future__ import annotations

from pathlib import Path

import httpx
import structlog

from autodev.core.config import get_settings
from autodev.core.exceptions import DeployError

log = structlog.get_logger(__name__)

VERCEL_DEPLOY_URL = "https://api.vercel.com/v13/deployments"


async def push(job_id: str, job_dir: Path) -> dict:
    settings = get_settings()
    if not settings.vercel_token:
        raise DeployError("push", "Vercel token not configured (VERCEL_TOKEN)")

    headers = {"Authorization": f"Bearer {settings.vercel_token}"}
    payload = {
        "name": f"autodev-{job_id[:8]}",
        "target": "production",
        "source": "api",
    }

    log.info("vercel_api.deploy", job_id=job_id)
    async with httpx.AsyncClient() as client:
        resp = await client.post(VERCEL_DEPLOY_URL, json=payload, headers=headers, timeout=30)
        if resp.status_code not in (200, 201):
            raise DeployError("push", f"Vercel API error {resp.status_code}: {resp.text}")
        data = resp.json()

    url = data.get("url", "")
    log.info("vercel_api.done", url=url)
    return {"target": "vercel", "deployment_id": data.get("id"), "url": url}
