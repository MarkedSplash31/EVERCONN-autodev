"""Unit tests for SchemaValidator."""

import json
import tempfile
from pathlib import Path

import pytest

from autodev.guard.schema_validator import SchemaValidator


def _make_schema_dir(schemas: dict[str, dict]) -> Path:
    """Write schema files to a temp directory and return its path."""
    tmpdir = Path(tempfile.mkdtemp())
    for name, schema in schemas.items():
        (tmpdir / name).write_text(json.dumps(schema), encoding="utf-8")
    return tmpdir


class TestSchemaValidator:
    def _make_simple_schema(self):
        return {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "required": ["job_id", "state"],
            "properties": {
                "job_id": {"type": "string"},
                "state": {"type": "string", "enum": ["RUNNING", "SUCCESS", "FAILED"]},
            },
        }

    def test_validate_valid_data(self):
        schema = self._make_simple_schema()
        schema_dir = _make_schema_dir({"status.schema.json": schema})
        validator = SchemaValidator(schema_dir)
        errors = validator.validate_data({"job_id": "abc", "state": "SUCCESS"}, "status")
        assert errors == []

    def test_validate_missing_required_field(self):
        schema = self._make_simple_schema()
        schema_dir = _make_schema_dir({"status.schema.json": schema})
        validator = SchemaValidator(schema_dir)
        errors = validator.validate_data({"job_id": "abc"}, "status")
        assert any("state" in e for e in errors)

    def test_validate_wrong_type(self):
        schema = self._make_simple_schema()
        schema_dir = _make_schema_dir({"status.schema.json": schema})
        validator = SchemaValidator(schema_dir)
        errors = validator.validate_data({"job_id": 123, "state": "SUCCESS"}, "status")
        assert len(errors) > 0

    def test_unknown_schema_returns_error(self):
        schema_dir = _make_schema_dir({})
        validator = SchemaValidator(schema_dir)
        errors = validator.validate_data({}, "nonexistent_schema")
        assert len(errors) == 1
        assert "not available" in errors[0]

    def test_validate_file_valid(self):
        schema = self._make_simple_schema()
        schema_dir = _make_schema_dir({"status.schema.json": schema})
        validator = SchemaValidator(schema_dir)
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
            json.dump({"job_id": "abc", "state": "RUNNING"}, f)
            file_path = Path(f.name)
        errors = validator.validate_file(file_path, "status")
        assert errors == []
        file_path.unlink()

    def test_validate_file_invalid_json(self):
        schema_dir = _make_schema_dir({"status.schema.json": self._make_simple_schema()})
        validator = SchemaValidator(schema_dir)
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
            f.write("{not valid json}")
            file_path = Path(f.name)
        errors = validator.validate_file(file_path, "status")
        assert len(errors) > 0
        file_path.unlink()

    def test_schema_is_cached(self):
        schema = self._make_simple_schema()
        schema_dir = _make_schema_dir({"status.schema.json": schema})
        validator = SchemaValidator(schema_dir)
        validator.validate_data({"job_id": "a", "state": "SUCCESS"}, "status")
        assert "status" in validator._cache
