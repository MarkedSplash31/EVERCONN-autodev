"""Unit tests for RolloutPolicy."""

import pytest

from autodev.deployer.rollout_policy import RolloutPolicy


class TestRolloutPolicy:
    def test_default_values(self):
        policy = RolloutPolicy()
        assert policy.strategy == "immediate"
        assert policy.canary_percent == 10
        assert policy.max_error_rate == 0.05
        assert policy.rollback_on_failure is True
        assert policy.notify_on_success is True
        assert policy.notify_on_failure is True

    def test_from_dict_full(self):
        data = {
            "strategy": "canary",
            "canary_percent": 20,
            "max_error_rate": 0.1,
            "rollback_on_failure": False,
            "notify_on_success": False,
            "notify_on_failure": True,
        }
        policy = RolloutPolicy.from_dict(data)
        assert policy.strategy == "canary"
        assert policy.canary_percent == 20
        assert policy.max_error_rate == 0.1
        assert policy.rollback_on_failure is False

    def test_from_dict_partial_uses_defaults(self):
        policy = RolloutPolicy.from_dict({"strategy": "blue_green"})
        assert policy.strategy == "blue_green"
        assert policy.canary_percent == 10  # default

    def test_to_dict_round_trip(self):
        original = RolloutPolicy(strategy="canary", canary_percent=25)
        restored = RolloutPolicy.from_dict(original.to_dict())
        assert restored.strategy == "canary"
        assert restored.canary_percent == 25

    def test_to_dict_contains_all_fields(self):
        policy = RolloutPolicy()
        d = policy.to_dict()
        assert "strategy" in d
        assert "canary_percent" in d
        assert "max_error_rate" in d
        assert "rollback_on_failure" in d
