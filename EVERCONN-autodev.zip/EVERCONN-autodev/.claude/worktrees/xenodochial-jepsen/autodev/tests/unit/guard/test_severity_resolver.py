"""Unit tests for SeverityResolver."""

import pytest

from autodev.guard.severity_resolver import SeverityResolver, DEFAULT_SEVERITY


class TestSeverityResolver:
    def _make_policy(self, severity_map=None, blocking=None):
        return {
            "severity_map": severity_map or {"missing_meta": "critical", "schema_meta": "error"},
            "blocking_severities": blocking or ["critical", "error"],
        }

    def test_resolve_known_rule(self):
        resolver = SeverityResolver(self._make_policy())
        assert resolver.resolve("missing_meta") == "critical"

    def test_resolve_unknown_rule_returns_default(self):
        resolver = SeverityResolver(self._make_policy())
        assert resolver.resolve("unknown_rule") == DEFAULT_SEVERITY

    def test_is_blocking_critical(self):
        resolver = SeverityResolver(self._make_policy())
        assert resolver.is_blocking("missing_meta") is True

    def test_is_blocking_error(self):
        resolver = SeverityResolver(self._make_policy())
        assert resolver.is_blocking("schema_meta") is True

    def test_is_not_blocking_warning(self):
        policy = self._make_policy(
            severity_map={"diff_missing": "warning"},
            blocking=["critical", "error"],
        )
        resolver = SeverityResolver(policy)
        assert resolver.is_blocking("diff_missing") is False

    def test_is_blocking_severity_critical(self):
        resolver = SeverityResolver(self._make_policy())
        assert resolver.is_blocking_severity("critical") is True

    def test_is_blocking_severity_info(self):
        resolver = SeverityResolver(self._make_policy())
        assert resolver.is_blocking_severity("info") is False

    def test_empty_policy_uses_defaults(self):
        resolver = SeverityResolver({})
        assert resolver.resolve("any") == DEFAULT_SEVERITY
        assert resolver.is_blocking("any") is False
