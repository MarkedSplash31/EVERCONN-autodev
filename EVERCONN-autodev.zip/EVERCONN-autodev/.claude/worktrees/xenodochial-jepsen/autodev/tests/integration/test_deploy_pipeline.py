"""Integration test: deployment pipeline."""

import pytest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from autodev.deployer.deploy_pipeline import DeployPipeline, StageStatus


@pytest.mark.integration
class TestDeployPipeline:
    @pytest.mark.asyncio
    async def test_pipeline_halts_on_first_failure(self, tmp_path):
        from autodev.core.exceptions import DeployError

        job_id = "pipeline-test-001"

        with patch("autodev.deployer.stages.stage_lint.run", AsyncMock(side_effect=DeployError("lint", "ruff fail"))):
            pipeline = DeployPipeline(job_id=job_id, target="local_docker", job_dir=tmp_path)
            result = await pipeline.run()

        assert result.success is False
        assert result.stages[0].status == StageStatus.FAILED
        assert len(result.stages) == 1  # halted after lint

    @pytest.mark.asyncio
    async def test_pipeline_succeeds_when_all_stages_pass(self, tmp_path):
        mock_output = {"status": "ok"}

        patches = {
            "autodev.deployer.stages.stage_lint.run": AsyncMock(return_value=mock_output),
            "autodev.deployer.stages.stage_test.run": AsyncMock(return_value=mock_output),
            "autodev.deployer.stages.stage_build.run": AsyncMock(return_value=mock_output),
            "autodev.deployer.stages.stage_guard_verify.run": AsyncMock(return_value=mock_output),
            "autodev.deployer.stages.stage_push.run": AsyncMock(return_value=mock_output),
            "autodev.deployer.stages.stage_notify.run": AsyncMock(return_value=mock_output),
        }

        with patch.multiple("", **{k: v for k, v in patches.items()}):
            # Patch each module individually
            import autodev.deployer.stages.stage_lint as sl
            import autodev.deployer.stages.stage_test as st
            import autodev.deployer.stages.stage_build as sb
            import autodev.deployer.stages.stage_guard_verify as sgv
            import autodev.deployer.stages.stage_push as sp
            import autodev.deployer.stages.stage_notify as sn

            with (
                patch.object(sl, "run", AsyncMock(return_value=mock_output)),
                patch.object(st, "run", AsyncMock(return_value=mock_output)),
                patch.object(sb, "run", AsyncMock(return_value=mock_output)),
                patch.object(sgv, "run", AsyncMock(return_value=mock_output)),
                patch.object(sp, "run", AsyncMock(return_value=mock_output)),
                patch.object(sn, "run", AsyncMock(return_value=mock_output)),
            ):
                pipeline = DeployPipeline(job_id="ok-job", target="local_docker", job_dir=tmp_path)
                result = await pipeline.run()

        assert result.success is True
        assert all(s.status == StageStatus.PASSED for s in result.stages)
