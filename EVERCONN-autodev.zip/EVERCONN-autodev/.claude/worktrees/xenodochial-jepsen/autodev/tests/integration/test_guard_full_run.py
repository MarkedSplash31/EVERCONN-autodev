"""Integration test: full guard pipeline run."""

import json
import tempfile
from pathlib import Path

import pytest

from autodev.core.constants import VERIFIER_NAME
from autodev.guard.guard_runner import GuardRunner


def _write_job_fixtures(job_dir: Path) -> None:
    """Write minimal valid artifacts for a job."""
    (job_dir / "meta.json").write_text(
        json.dumps({"job_id": "test-job", "created_at": "2026-01-01T00:00:00Z", "description": "test"}),
        encoding="utf-8",
    )
    (job_dir / "manifest.json").write_text(
        json.dumps({"job_id": "test-job", "scope": "artifacts_only", "artifacts": {}}),
        encoding="utf-8",
    )
    (job_dir / "status.json").write_text(
        json.dumps({"job_id": "test-job", "state": "SUCCESS"}),
        encoding="utf-8",
    )
    (job_dir / "verification.json").write_text(
        json.dumps({
            "job_id": "test-job",
            "verifier": {"name": VERIFIER_NAME, "version": "1.0"},
            "passed": True,
        }),
        encoding="utf-8",
    )


@pytest.mark.integration
class TestGuardFullRun:
    def test_guard_pass_with_valid_artifacts(self, tmp_path, monkeypatch):
        job_id = "integration-test-001"
        job_dir = tmp_path / "jobs" / job_id
        job_dir.mkdir(parents=True)
        artifacts_dir = tmp_path / "artifacts"

        _write_job_fixtures(job_dir)
        monkeypatch.setenv("RUNTIME_DIR", str(tmp_path))
        monkeypatch.setenv("ARTIFACTS_DIR", str(artifacts_dir))
        monkeypatch.setenv("GUARD_SCHEMA_DIR", "contracts/runtime/schemas")
        monkeypatch.setenv("GUARD_POLICY_PATH", "contracts/runtime/policy.yaml")

        from autodev.core.config import get_settings
        get_settings.cache_clear()

        runner = GuardRunner(job_id=job_id)
        # Override paths for test isolation
        runner.writer.artifacts_dir = artifacts_dir

        report = runner.run(job_dir)
        blocking = [v for v in report.violations if v.severity in ("critical", "error")]
        # Schema files may not be present in test env — check verifier name at minimum
        verifier_violations = [v for v in report.violations if v.rule == "verifier_name_mismatch"]
        assert len(verifier_violations) == 0

    def test_guard_fail_wrong_verifier_name(self, tmp_path):
        job_id = "integration-test-002"
        job_dir = tmp_path / "jobs" / job_id
        job_dir.mkdir(parents=True)

        _write_job_fixtures(job_dir)
        # Overwrite with wrong verifier name
        (job_dir / "verification.json").write_text(
            json.dumps({"job_id": job_id, "verifier": {"name": "wrong_guard", "version": "1.0"}}),
            encoding="utf-8",
        )

        runner = GuardRunner.__new__(GuardRunner)
        runner.job_id = job_id
        from autodev.guard.hash_engine import HashEngine
        from autodev.guard.manifest_builder import ManifestBuilder
        from autodev.guard.artifact_writer import ArtifactWriter
        from autodev.guard.schema_validator import SchemaValidator
        from autodev.guard.severity_resolver import SeverityResolver
        from autodev.guard.policy_loader import PolicyLoader

        runner.policy = PolicyLoader._default_policy()
        runner.severity = SeverityResolver(runner.policy)
        runner.hash_engine = HashEngine()
        runner.manifest_builder = ManifestBuilder(job_id=job_id)
        runner.validator = SchemaValidator(Path("contracts/runtime/schemas"))
        runner.writer = ArtifactWriter(job_id=job_id, artifacts_dir=tmp_path / "artifacts")

        report = runner.run(job_dir)
        verifier_violations = [v for v in report.violations if v.rule == "verifier_name_mismatch"]
        assert len(verifier_violations) == 1
        assert report.passed is False
