"""Project-wide constants. Single source of truth — do not duplicate elsewhere."""

# ── Job lifecycle states ───────────────────────────────────────────────────────
JOB_STATES = ["RUNNING", "SUCCESS", "FAILED", "ABORTED", "TRUNCATED", "SKIPPED"]

# ── Guard / verification ───────────────────────────────────────────────────────
# Must match the `verifier.name` enum value in verification.schema.json exactly.
VERIFIER_NAME = "runtime_guard"

# ── Artifact filename map ──────────────────────────────────────────────────────
# Maps logical artifact key → filename written under runtime/jobs/<job_id>/
ARTIFACT_MAP: dict[str, str] = {
    "meta": "meta.json",
    "plan": "plan.json",
    "events": "events.jsonl",
    "verification": "verification.json",
    "manifest": "manifest.json",
    "status": "status.json",
    # conditional artifacts
    "commands": "commands.jsonl",   # present only when commands_executed=true
    "diff": "diff.patch",           # present only when repo_changed=true
    "patchset": "patchset.json",    # optional sealed patchset
}

# ── Schema filenames ───────────────────────────────────────────────────────────
SCHEMA_FILES = {
    "manifest": "manifest.schema.json",
    "meta": "meta.schema.json",
    "status": "status.schema.json",
    "verification": "verification.schema.json",
}

# ── Hash algorithm identifier (written into verification.json) ─────────────────
HASH_ALGORITHM = "sha256+json_sortkeys_compact_utf8_v1"
