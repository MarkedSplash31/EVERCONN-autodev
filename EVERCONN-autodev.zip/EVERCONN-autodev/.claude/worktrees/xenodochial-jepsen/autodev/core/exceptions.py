"""Domain exceptions for autodev."""


class AutodevError(Exception):
    """Base exception for all autodev errors."""


class GuardError(AutodevError):
    """Raised when the runtime guard fails verification."""

    def __init__(self, message: str, job_id: str | None = None) -> None:
        super().__init__(message)
        self.job_id = job_id


class PolicyViolationError(GuardError):
    """Raised when a policy rule blocks an operation."""

    def __init__(self, rule: str, severity: str, job_id: str | None = None) -> None:
        super().__init__(f"Policy violation: rule={rule!r} severity={severity}", job_id)
        self.rule = rule
        self.severity = severity


class SchemaValidationError(AutodevError):
    """Raised when a JSON artifact fails schema validation."""

    def __init__(self, schema_name: str, errors: list[str]) -> None:
        super().__init__(f"Schema '{schema_name}' validation failed: {errors}")
        self.schema_name = schema_name
        self.errors = errors


class SandboxError(AutodevError):
    """Raised when a sandboxed operation is forbidden."""


class JobNotFoundError(AutodevError):
    """Raised when a job ID cannot be resolved."""

    def __init__(self, job_id: str) -> None:
        super().__init__(f"Job not found: {job_id!r}")
        self.job_id = job_id


class DeployError(AutodevError):
    """Raised when a deployment stage fails."""

    def __init__(self, stage: str, reason: str) -> None:
        super().__init__(f"Deploy failed at stage={stage!r}: {reason}")
        self.stage = stage
        self.reason = reason
