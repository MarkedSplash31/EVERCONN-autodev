// AUTODEV_STUB — everconn frontend entrypoint
// This file will be populated by the autodev agent

import React from 'react';
import { createRoot } from 'react-dom/client';

function App() {
  return <div><h1>EVERCONN</h1></div>;
}

createRoot(document.getElementById('root')).render(<App />);
