# Agent Flows

## Job execution flow

```
POST /jobs/  { description: "..." }
  └── AutodevAgent.run(description)
        ├── TaskPlanner.decompose()     → Plan (list of PlanSteps)
        └── for each step:
              DecisionEngine.execute_step(step)
                └── importlib → skill.execute(step, context)
```

## Skills

| Skill | Purpose |
|-------|---------|
| `file_manager` | Read/write/list files in sandbox workspace |
| `code_generator` | Generate new code via Claude |
| `code_modifier` | Apply targeted modifications to existing code |
| `code_reviewer` | Review code for quality and security |
| `test_generator` | Generate pytest test suites |
| `dependency_resolver` | Extract and resolve package dependencies |
| `schema_inferrer` | Infer JSON Schema from example data |

## Memory layers

- **JobMemory** — per-job, in `runtime/jobs/<job_id>/`, ephemeral
- **LongtermMemory** — Pinecone vector store, persists across jobs
- **CodebaseIndex** — in-memory file index, rebuilt per session
