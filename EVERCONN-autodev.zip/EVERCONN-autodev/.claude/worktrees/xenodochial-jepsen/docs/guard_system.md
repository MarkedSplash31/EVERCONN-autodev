# Guard System

The runtime guard is the integrity layer that validates all job artifacts before they are promoted to `contracts/runtime/artifacts/`.

## Pipeline

```
GuardRunner.run(job_dir)
  ├── PolicyLoader.load()              → policy dict
  ├── SchemaValidator.validate_file()  → per-artifact JSON Schema validation
  ├── verifier.name check              → must equal VERIFIER_NAME = "runtime_guard"
  ├── ManifestBuilder.build()          → artifact manifest with sha256 per file
  ├── HashEngine.hash_manifest()       → deterministic verification hash
  └── ArtifactWriter.write()           → only on PASS — copies to contracts/
```

## Severity levels

| Level | Blocking | Examples |
|-------|----------|---------|
| `critical` | Yes | missing required artifact, wrong verifier name, hash mismatch |
| `error` | Yes | schema validation failure |
| `warning` | No | missing commands log |
| `info` | No | missing diff |

## Hash algorithm

`sha256+json_sortkeys_compact_utf8_v1`: serialize the manifest dict as compact JSON with sorted keys, encode as UTF-8, compute sha256. This is deterministic across platforms.

## VERIFIER_NAME constraint

`verification.json` must have `verifier.name = "runtime_guard"` (the exact string defined in `constants.py`). The schema enforces this via `enum: ["runtime_guard"]`. Any other value causes a `critical` violation and blocks the pipeline.
