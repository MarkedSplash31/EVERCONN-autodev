# Architecture

## Overview

EVERCONN-autodev is a layered autonomous development system. Each layer has a single responsibility and communicates through well-defined interfaces.

```
┌─────────────────────────────────────────────────┐
│                   HTTP API                      │  ← FastAPI (autodev/api/)
├─────────────────────────────────────────────────┤
│                  Agent Layer                    │  ← Claude-powered (autodev/agent/)
│  TaskPlanner → DecisionEngine → Skills          │
├─────────────────────────────────────────────────┤
│                Executor Layer                   │  ← (autodev/executor/)
│  CommandRunner · DiffEngine · EventEmitter      │
├─────────────────────────────────────────────────┤
│                 Guard Layer                     │  ← (autodev/guard/)
│  PolicyLoader → SchemaValidator → ManifestBuilder → ArtifactWriter
├─────────────────────────────────────────────────┤
│               Deployer Layer                    │  ← (autodev/deployer/)
│  lint → test → build → guard_verify → push → notify
└─────────────────────────────────────────────────┘
```

## Key invariants

1. **Guard PASS is mandatory** before any artifact is written to `contracts/runtime/artifacts/`
2. **`VERIFIER_NAME = "runtime_guard"`** — this string must match `verification.schema.json` exactly
3. **Job states** are the closed set: `RUNNING | SUCCESS | FAILED | ABORTED | TRUNCATED | SKIPPED`
4. **Hash algorithm** is `sha256+json_sortkeys_compact_utf8_v1` — deterministic, reproducible
