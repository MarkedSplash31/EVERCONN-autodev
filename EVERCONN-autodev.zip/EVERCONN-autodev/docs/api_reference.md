# API Reference

Base URL: `http://localhost:8000`

## Jobs

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/jobs/` | Create a new job |
| `GET` | `/jobs/` | List all jobs |
| `GET` | `/jobs/{job_id}` | Get job status |
| `POST` | `/jobs/{job_id}/abort` | Abort a running job |

## Guard

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/guard/run` | Run guard for a job |
| `GET` | `/guard/{job_id}/result` | Get guard result |

## Deploy

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/deploy/` | Trigger deployment |
| `GET` | `/deploy/{job_id}/status` | Get deployment status |

## Sandbox

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/sandbox/run` | Run templated operation |
| `GET` | `/sandbox/templates` | List available templates |
| `DELETE` | `/sandbox/workspace/{job_id}` | Cleanup workspace |

## Policies

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/policies/` | List policies |
| `GET` | `/policies/{name}` | Get policy details |

## Health

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/health` | Health check |
